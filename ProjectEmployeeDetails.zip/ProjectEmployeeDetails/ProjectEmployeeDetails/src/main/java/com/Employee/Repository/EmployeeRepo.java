package com.Employee.Repository;

import org.springframework.data.repository.CrudRepository;

import com.Employee.Entity.Employee;


public interface EmployeeRepo extends CrudRepository<Employee, Integer>{

	public Employee findByIdAndPassword(int id,String password);
	
	public String existsById(int id);
	
	
}
