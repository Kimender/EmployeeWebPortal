package com.Employee.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class HR {
	
	@Id
	@Column(name="ID")
	private int iD;
	@Column(name="Password")
	private String password;
	
	public HR() {
		super();
		
	}

	public HR(int iD, String password) {
		super();
		this.iD = iD;
		this.password = password;
	}

	public int getiD() {
		return iD;
	}

	public void setiD(int iD) {
		this.iD = iD;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "HR [iD=" + iD + ", password=" + password + "]";
	}
	
	
	

}
