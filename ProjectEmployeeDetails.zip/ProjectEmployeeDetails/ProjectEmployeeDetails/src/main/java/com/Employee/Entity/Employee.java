package com.Employee.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Employee {
	
	@Id
	@Column(name="ID")
	private int id;
	
	@Column(name="Name")
	private String name;
	
	@Column(name="Age")
	private int age;
	
	@Column(name="Password")
	private String password;
	
	@Column(name="HR")
	private String hr;
	
	@Column(name="Designation")
	private String designation;
	
	@Column(name="PhoneNo")
	private long phoneNo;
	
	@Column(name="Address")
	private String address;
	
	@Column(name="Email_ID")
	private String email;

	public Employee() {
		super();
		
	}

	public Employee(int id, String name, int age, String password, String hr, String designation, long phoneNo,
			String address, String email) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.password = password;
		this.hr = hr;
		this.designation = designation;
		this.phoneNo = phoneNo;
		this.address = address;
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHr() {
		return hr;
	}

	public void setHr(String hr) {
		this.hr = hr;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age + ", password=" + password + ", hr=" + hr
				+ ", designation=" + designation + ", phoneNo=" + phoneNo + ", address=" + address + ", email=" + email
				+ "]";
	}
	
	
	
	

}
