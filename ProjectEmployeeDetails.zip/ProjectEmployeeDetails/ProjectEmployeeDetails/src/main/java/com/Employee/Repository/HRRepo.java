package com.Employee.Repository;

import org.springframework.data.repository.CrudRepository;

import com.Employee.Entity.HR;


public interface HRRepo extends CrudRepository<HR,Integer>{
	
	public HR findByIDAndPassword(int id,String password);
	
	public String existsByID(int id);
	
	public String findPasswordByiD(int id);

}
