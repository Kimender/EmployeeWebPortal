package com.Employee.Controller;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Employee.Entity.Employee;
import com.Employee.Entity.HR;
import com.Employee.Repository.EmployeeRepo;
import com.Employee.Repository.HRRepo;



@Controller
public class MyController {

	@Autowired
	private HRRepo repo;
	
	@Autowired
	private EmployeeRepo repoE;
	
	@RequestMapping("/")
	public String homePage()
	{
		System.out.println("Inside home page");
		return "Home";
	}
	
	@RequestMapping("/Employee")
	public String loginEmployee()
	{
		System.out.println("Inside Login page");
		return "LoginEmployee";
	}
	
	@RequestMapping("/HR")
	public String loginHR()
	{
		System.out.println("Inside Login page");
		return "LoginHR";
	}
	
	@RequestMapping("/profileHR")
	public String profileHR()
	{
		return "Profile_HR";
	}
	
	@PostMapping("/log")
	public String afterLoginHR(@RequestParam("EmployeeID") int EmployeeID,@RequestParam("Password") String password,jakarta.servlet.http.HttpSession session,Model m,HR hr)
	{
		hr=repo.findByIDAndPassword(EmployeeID, password);
		System.out.println(hr);
		
		if(hr==null)
			 return "home";
		String idFound=repo.existsByID(EmployeeID);
		
		if(idFound.equals("true"))
		{
			System.out.println("hello world");
			
			String pass=hr.getPassword();
			
			System.out.println("Password = "+pass);
			
			if(pass.equals(password))
			{
				System.out.println("Employee "+EmployeeID + " have successfully logged in");
				
				return "Profile_HR";
			}
			return "home";
		}
		
		return "Home";
	}
	@RequestMapping("/AddEmployee")
	public String addEmployee()
	{
		return "AddEmployee";
	}
	
	@PostMapping("/add")
	public String add(@ModelAttribute("employeeData") Employee e, jakarta.servlet.http.HttpSession session)
	{
		String present=repoE.existsById(e.getId());
		System.out.println("optional : "+present  );
		
		if(present.equals("true"))
		{
			System.out.println("Username "+ e.getId()+" already exists.Try adding different Employee..");
			//session.setAttribute("message2","Username "+e.getId()+ " Already exists.Try creating a new Employee...!!!");
			return "redirect:/AddEmployee";
		}
		
        System.out.println(e);
		
		repoE.save(e);
		//session.setAttribute("message","Registered Successfully");
		return "redirect:/AddEmployee";
		
	}
}
